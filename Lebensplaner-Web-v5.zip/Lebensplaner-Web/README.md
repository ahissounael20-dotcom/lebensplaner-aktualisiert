# Lebensplaner Web

1. Entpacke die ZIP-Datei.
2. Lade **alle** Dateien in die oberste Ebene deines GitHub-Pages-Repositories: `index.html`, `manifest.webmanifest`, `sw.js` und `icon.svg`.
3. In GitHub: **Settings → Pages → Deploy from a branch → main → / (root)**.
4. Öffne die veröffentlichte `https://…github.io/…/`-Adresse in Safari auf dem iPad und wähle **Teilen → Zum Home-Bildschirm**.

Die App arbeitet lokal-first. Aufgaben und private Einträge bleiben im Browser-Speicher des jeweiligen Geräts. Nutze in **Mehr → Einstellungen → Export** regelmäßig eine Sicherung.
